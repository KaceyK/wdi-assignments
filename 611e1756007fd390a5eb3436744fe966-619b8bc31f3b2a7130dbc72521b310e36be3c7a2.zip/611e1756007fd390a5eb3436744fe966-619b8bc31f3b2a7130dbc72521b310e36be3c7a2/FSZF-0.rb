# Excercise


# def sentence(n)
# n + ' Only in America'
# end
# a = sentence'Obesity'

# puts a


# Exercise 2

# a = [-10000, 10, 100, 450, 1265, -5]
# a[4]


# Exercise 3

# Movies =[["Nerve:"," Emma Roberts"],["Trolls:"," Anna Kendrick"]]
# Movies.each do |my_movies| 
#   puts "#{my_movies[0]+my_movies[1]}"
# end


 
 
# Exercise 4


# (1..100).each do |number|
#   fizz = number % 3 == 0
#   buzz = number % 5 == 0
#   p "Fizz" if fizz
#   p "Buzz" if buzz
#   p number if !fizz && !buzz
  
# end









